package com.bitc.dao;

public interface MemberDAOImpl {

}
