package com.bitc.service;

public interface MemberSerivceImpl {
	
}
